/* XMRig
 * Copyright 2010      Jeff Garzik <jgarzik@pobox.com>
 * Copyright 2012-2014 pooler      <pooler@litecoinpool.org>
 * Copyright 2014      Lucas Jones <https://github.com/lucasjones>
 * Copyright 2014-2016 Wolf9466    <https://github.com/OhGodAPet>
 * Copyright 2016      Jay D Dee   <jayddee246@gmail.com>
 * Copyright 2016-2017 XMRig       <support@xmrig.com>
 *
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __OPTIONS_H__
#define __OPTIONS_H__


#include <vector>
#include <stdint.h>


class Url;


class Options
{
public:
    enum Algo {
        ALGO_CRYPTONIGHT,      /* CryptoNight (Monero) */
        ALGO_CRYPTONIGHT_LITE, /* CryptoNight-Lite (AEON) */
    };

    enum AlgoVariant {
        AV0_AUTO,
        AV1_AESNI,
        AV2_AESNI_DOUBLE,
        AV3_SOFT_AES,
        AV4_SOFT_AES_DOUBLE,
        AV_MAX
    };

    static inline Options* i() { return m_self; }
    static Options *parse(int argc, char **argv);

    inline bool background() const                { return m_background; }
    inline bool colors() const                    { return m_colors; }
    inline bool doubleHash() const                { return m_doubleHash; }
    inline bool isReady() const                   { return m_ready; }
    inline bool syslog() const                    { return m_syslog; }
    inline const char *logFile() const            { return m_logFile; }
    inline const std::vector<Url*> &pools() const { return m_pools; }
    inline int algo() const                       { return m_algo; }
    inline int algoVariant() const                { return m_algoVariant; }
    inline int donateLevel() const                { return m_donateLevel; }
    inline int printTime() const                  { return m_printTime; }
    inline int retries() const                    { return m_retries; }
    inline int retryPause() const                 { return m_retryPause; }
    inline int threads() const                    { return m_threads; }
    inline int64_t affinity() const               { return m_affinity; }

    const char *algoName() const;

private:
    Options(int argc, char **argv);
    ~Options();

    static Options *m_self;

    bool parseArg(int key, char *arg);
    Url *parseUrl(const char *arg) const;
    void showUsage(int status) const;
    void showVersion(void);

    bool setAlgo(const char *algo);

    int getAlgoVariant() const;
#   ifndef XMRIG_NO_AEON
    int getAlgoVariantLite() const;
#   endif

    bool m_background;
    bool m_colors;
    bool m_doubleHash;
    bool m_ready;
    bool m_safe;
    bool m_syslog;
    char *m_logFile;
    int m_algo;
    int m_algoVariant;
    int m_donateLevel;
    int m_maxCpuUsage;
    int m_printTime;
    int m_retries;
    int m_retryPause;
    int m_threads;
    int64_t m_affinity;
    std::vector<Url*> m_pools;
};

#endif /* __OPTIONS_H__ */
